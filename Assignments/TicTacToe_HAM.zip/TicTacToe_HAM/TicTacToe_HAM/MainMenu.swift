//
//  ViewController.swift
//  TicTacToe_HAM
//
//  Created by Hugh A. Miles on 9/8/15.
//  Copyright © 2015 HAM. All rights reserved.
//

import UIKit

class MainMenu: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

